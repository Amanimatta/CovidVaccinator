<?php
$serverName = "LAPTOP-7C5SJ8A7";
//connection using Windows Authentication and pdo driver
try  
{  
    $conn = new PDO( "sqlsrv:server=$serverName ; Database=covidvaccinator", "", "");  
    $conn->setAttribute( PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION ); 
}  
catch(Exception $e)  
{   
    die( print_r( $e->getMessage() ) );   
}  

?>