<?php
  include "header.php";
  session_destroy();

  echo "<hr><br>Thank you for signing up to be vaccinated.<br>";
  echo "<br>With your help we can eradicate Covid-19.<br>";
  echo "<br><br><a href='index.html'><button>Back To Homepage</button></a> to login<br><hr>";

  echo "<br>";
?>
