<?php

  echo <<<_END


<select name="state" id = "state" required>
  <option value="AL">AL</option>
  <option value="AK">AK</option>
  <option value="AZ">AZ</option>
  <option value="AR">AR</option>
  <option value="CA">CA</option>
  <option value="CO">CO</option>
  <option value="MA">MA</option>
  <option value="MN">MN</option>
  <option value="NJ">NJ</option>
  <option value="NY" selected>NY</option>
  <option value="WI">WI</option>
</select>

_END;
?>
