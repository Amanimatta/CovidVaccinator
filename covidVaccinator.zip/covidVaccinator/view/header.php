<?php
session_start();

echo <<<_END
<head>
<link href = "style.css" rel = "stylesheet">
<script src='../view/validate_functions.js'></script>
</head>

<body>
<div class = "head">
  <h1>Covid Vaccinator</h1>
_END;
?>
